package br.com.leonardo.injectm

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.roundToInt

private val Neon = Color(0xFF00C8FF)
private val Cyan = Color(0xFF48F0FF)
private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101F32)
private val Muted = Color(0xFF91A8BE)
private val LocalCompactCards = androidx.compose.runtime.compositionLocalOf { false }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { InjectMApp() }
    }
}

data class DeviceSnapshot(
    val manufacturer: String,
    val model: String,
    val android: String,
    val ramTotal: Long,
    val ramAvailable: Long,
    val storageTotal: Long,
    val storageAvailable: Long,
    val batteryPercent: Int,
    val batteryTemp: Float?,
    val batteryCharging: Boolean
) {
    val ramUsedPercent: Int get() = if (ramTotal > 0) (((ramTotal - ramAvailable).toDouble() / ramTotal) * 100).roundToInt() else 0
    val storageUsedPercent: Int get() = if (storageTotal > 0) (((storageTotal - storageAvailable).toDouble() / storageTotal) * 100).roundToInt() else 0
}

private fun readDevice(context: Context): DeviceSnapshot {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mem = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mem)
    val stat = StatFs(Environment.getDataDirectory().absolutePath)
    val totalStorage = stat.totalBytes
    val availableStorage = stat.availableBytes
    val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
    val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
    val pct = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt() else -1
    val tempRaw = battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
    val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    return DeviceSnapshot(
        Build.MANUFACTURER.orEmpty().replaceFirstChar { it.uppercase() },
        Build.MODEL.orEmpty(),
        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
        mem.totalMem, mem.availMem, totalStorage, availableStorage,
        pct, if (tempRaw >= 0) tempRaw / 10f else null, charging
    )
}

private fun bytes(value: Long): String {
    val gb = value / 1024.0 / 1024.0 / 1024.0
    return if (gb >= 1) String.format(Locale.getDefault(), "%.2f GB", gb)
    else String.format(Locale.getDefault(), "%.0f MB", value / 1024.0 / 1024.0)
}

private data class LaunchableApp(val label: String, val packageName: String, val isSystem: Boolean)

private fun launchableApps(context: Context): List<LaunchableApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return try {
        @Suppress("DEPRECATION")
        pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                if (pkg == context.packageName) return@mapNotNull null
                val label = info.loadLabel(pm)?.toString() ?: pkg
                LaunchableApp(label, pkg, (info.activityInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0)
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    } catch (_: Exception) { emptyList() }
}

private enum class AppTab(val title: String, val icon: ImageVector) {
    HOME("Início", Icons.Default.Home),
    OPTIMIZE("Otimização", Icons.Default.Tune),
    GAME("Game Boost", Icons.Default.SportsEsports),
    TOOLS("Ferramentas", Icons.Default.Build),
    SETTINGS("Configurações", Icons.Default.Settings)
}

private val themeNames = listOf("BLUE NEON", "CYBER BLUE", "MIDNIGHT", "DEEP OCEAN", "ICE BLUE")
private val tutorialTitles = listOf(
    "Conhecendo o INJECT M", "Tela inicial", "Otimização", "Game Boost",
    "Ferramentas", "Personalização", "Finalização"
)
private val tutorialBodies = listOf(
    "O INJECT M reúne informações reais do aparelho e atalhos úteis em uma interface única. Os dados são lidos diretamente das APIs disponíveis no Android.",
    "Aqui você acompanha memória RAM, armazenamento, bateria e identificação do dispositivo. Os valores são atualizados ao entrar na tela e pelo botão Atualizar.",
    "A análise verifica memória disponível, espaço livre, bateria e dados do sistema. O relatório oferece recomendações; não promete liberar RAM nem apaga arquivos.",
    "Veja aplicativos que o Android permite iniciar. Escolha um item para abrir o próprio aplicativo. O Game Boost não altera FPS nem modifica configurações protegidas.",
    "Os monitores mostram dados do sistema. O gerenciador lista aplicativos com ícone de inicialização e permite abri-los. O Android limita o que apps comuns podem controlar.",
    "Escolha um dos cinco temas e ajuste brilho visual, animações e estilo dos cartões. As preferências ficam salvas neste aparelho.",
    "Você está pronto para utilizar o INJECT M! Você pode abrir este guia novamente em Configurações."
)

@Composable
fun InjectMApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("inject_m_prefs", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf(AppTab.HOME) }
    var theme by remember { mutableStateOf(prefs.getString("theme", "BLUE NEON") ?: "BLUE NEON") }
    var glow by remember { mutableFloatStateOf(prefs.getFloat("glow", 0.75f)) }
    var animations by remember { mutableStateOf(prefs.getBoolean("animations", true)) }
    var compactCards by remember { mutableStateOf(prefs.getBoolean("compact", false)) }
    var snapshot by remember { mutableStateOf(readDevice(context)) }
    var tutorialStep by remember { mutableIntStateOf(prefs.getInt("tutorial_step", 0)) }
    var tutorialOpen by remember { mutableStateOf(!prefs.getBoolean("tutorial_done", false)) }
    var helpText by remember { mutableStateOf<String?>(null) }
    var analysisRunning by remember { mutableStateOf(false) }
    var analysisDone by remember { mutableStateOf(false) }
    var appSearch by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            snapshot = readDevice(context)
            delay(5000)
        }
    }
    val baseAccent = when (theme) {
        "CYBER BLUE" -> Color(0xFF238BFF)
        "MIDNIGHT" -> Color(0xFF7388FF)
        "DEEP OCEAN" -> Color(0xFF00A6A6)
        "ICE BLUE" -> Color(0xFF8BE7FF)
        else -> Neon
    }
    val accent = baseAccent.copy(alpha = 0.60f + glow.coerceIn(0f, 1f) * 0.40f)
    val bg = Brush.verticalGradient(listOf(Color(0xFF07101D), Color(0xFF030811), Color(0xFF08182A)))
    CompositionLocalProvider(LocalCompactCards provides compactCards) {
    MaterialTheme(colorScheme = darkColorScheme(primary = accent, secondary = Cyan, background = Navy, surface = Panel)) {
        Box(Modifier.fillMaxSize().background(bg)) {
            if (tutorialOpen) {
                TutorialScreen(
                    step = tutorialStep,
                    onStep = { tutorialStep = it; prefs.edit().putInt("tutorial_step", it).apply() },
                    onFinish = {
                        tutorialOpen = false
                        prefs.edit().putBoolean("tutorial_done", true).putInt("tutorial_step", 6).apply()
                    },
                    onSkip = {
                        tutorialOpen = false
                        prefs.edit().putBoolean("tutorial_done", true).apply()
                    },
                    accent = accent
                )
            } else {
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        NavigationBar(containerColor = Color(0xFF081321), contentColor = Color.White) {
                            AppTab.values().forEach { item ->
                                NavigationBarItem(
                                    selected = tab == item,
                                    onClick = { tab = item },
                                    icon = { Icon(item.icon, contentDescription = item.title) },
                                    label = { Text(item.title, fontSize = 9.sp, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = accent,
                                        selectedTextColor = accent,
                                        indicatorColor = accent.copy(alpha = 0.14f),
                                        unselectedIconColor = Muted,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    AnimatedContent(
                        targetState = tab,
                        transitionSpec = { if (animations) fadeIn() togetherWith fadeOut() else EnterTransition.None togetherWith ExitTransition.None },
                        label = "tab-transition"
                    ) { page ->
                        when (page) {
                            AppTab.HOME -> HomeScreen(snapshot, accent, padding, onRefresh = { snapshot = readDevice(context) }, onHelp = { helpText = "Os indicadores são consultados no próprio Android. RAM disponível é a memória que o sistema informa como disponível; armazenamento mostra a partição de dados." }, onOptimize = { tab = AppTab.OPTIMIZE })
                            AppTab.OPTIMIZE -> OptimizeScreen(snapshot, accent, padding, analysisRunning, analysisDone,
                                onStart = {
                                    analysisRunning = true; analysisDone = false
                                }, onHelp = { helpText = "A análise é somente diagnóstica. O Android não permite que um aplicativo comum encerre processos de terceiros ou faça uma limpeza profunda do sistema." })
                            AppTab.GAME -> GameScreen(context, accent, padding, appSearch, { appSearch = it }, onHelp = { helpText = "Esta lista contém apps com atividade de inicialização detectável pelo Android. Tocar em um app abre esse aplicativo; não altera desempenho interno do jogo." })
                            AppTab.TOOLS -> ToolsScreen(context, snapshot, accent, padding, onHelp = { helpText = it }, onRefresh = { snapshot = readDevice(context) })
                            AppTab.SETTINGS -> SettingsScreen(
                                theme, { theme = it; prefs.edit().putString("theme", it).apply() },
                                glow, { glow = it; prefs.edit().putFloat("glow", it).apply() },
                                animations, { animations = it; prefs.edit().putBoolean("animations", it).apply() },
                                compactCards, { compactCards = it; prefs.edit().putBoolean("compact", it).apply() },
                                onTutorial = { tutorialStep = 0; tutorialOpen = true },
                                onContinue = { tutorialStep = prefs.getInt("tutorial_step", 0); tutorialOpen = true },
                                onReset = {
                                    prefs.edit().clear().apply()
                                    theme = "BLUE NEON"; glow = 0.75f; animations = true; compactCards = false
                                }, accent = accent, padding = padding
                            )
                        }
                    }
                }
                if (analysisRunning) {
                    LaunchedEffect(analysisRunning) {
                        delay(1800)
                        snapshot = readDevice(context)
                        analysisRunning = false
                        analysisDone = true
                    }
                }
            }
            helpText?.let { message ->
                AlertDialog(
                    onDismissRequest = { helpText = null },
                    title = { Text("Ajuda INJECT M", color = accent, fontWeight = FontWeight.Bold) },
                    text = { Text(message, color = Color.White) },
                    confirmButton = { TextButton(onClick = { helpText = null }) { Text("ENTENDI") } },
                    containerColor = Panel
                )
            }
        }
    }
    }
}

@Composable
private fun PageColumn(padding: PaddingValues, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(bottom = padding.calculateBottomPadding()),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) { item { Column(content = content) } }
}

@Composable
private fun Header(title: String, subtitle: String, accent: Color, help: (() -> Unit)? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Muted, fontSize = 12.sp)
        }
        if (help != null) IconButton(onClick = help) { Icon(Icons.Default.HelpOutline, null, tint = accent) }
    }
}

@Composable
private fun PanelCard(accent: Color, compact: Boolean? = null, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF142A42), Color(0xFF0B1727))))
            .padding(if (compact ?: LocalCompactCards.current) 14.dp else 17.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), content = content
    )
}

@Composable
private fun MetricCard(title: String, value: String, detail: String, percent: Float?, accent: Color, icon: ImageVector) {
    PanelCard(accent, compact = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(8.dp))
            Text(title, color = Muted, fontSize = 12.sp)
        }
        Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(detail, color = Muted, fontSize = 11.sp)
        if (percent != null) {
            val animated by animateFloatAsState(percent.coerceIn(0f, 100f) / 100f, label = "metric")
            LinearProgressIndicator(progress = { animated }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = accent, trackColor = Color(0xFF26384C))
        }
    }
}

@Composable
private fun HomeScreen(s: DeviceSnapshot, accent: Color, padding: PaddingValues, onRefresh: () -> Unit, onHelp: () -> Unit, onOptimize: () -> Unit) {
    PageColumn(padding) {
        Text("INJECT M", color = accent, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
        Text("DEVELOPED BY LEONARDO", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Header("Painel do dispositivo", "Olá! Aqui estão os dados atuais do aparelho.", accent, onHelp)
        PanelCard(accent) {
            Text("${s.manufacturer} ${s.model}", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(s.android, color = Muted, fontSize = 12.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("STATUS DO SISTEMA", color = Muted, fontSize = 10.sp, letterSpacing = 1.sp)
                Text("LEITURA AO VIVO", color = accent, fontSize = 10.sp, letterSpacing = 1.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                MetricCard("RAM disponível", bytes(s.ramAvailable), "Total: ${bytes(s.ramTotal)}", s.ramUsedPercent.toFloat(), accent, Icons.Default.Memory)
            }
            Box(Modifier.weight(1f)) {
                MetricCard("Armazenamento livre", bytes(s.storageAvailable), "Total: ${bytes(s.storageTotal)}", s.storageUsedPercent.toFloat(), accent, Icons.Default.Storage)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                MetricCard("Bateria", if (s.batteryPercent >= 0) "${s.batteryPercent}%" else "Indisponível", if (s.batteryCharging) "Carregando" else "Estado atual", null, accent, Icons.Default.BatteryFull)
            }
            Box(Modifier.weight(1f)) {
                MetricCard("Temperatura", s.batteryTemp?.let { String.format(Locale.getDefault(), "%.1f °C", it) } ?: "Indisponível", "Sensor da bateria", null, accent, Icons.Default.Thermostat)
            }
        }
        Button(onClick = onOptimize, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = accent), shape = RoundedCornerShape(15.dp)) {
            Text("ANALISAR DISPOSITIVO", color = Navy, fontWeight = FontWeight.ExtraBold)
        }
        OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth(), border = ButtonDefaults.outlinedButtonBorder.copy(brush = Brush.linearGradient(listOf(accent, Cyan)))) {
            Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("ATUALIZAR LEITURA")
        }
    }
}

@Composable
private fun OptimizeScreen(s: DeviceSnapshot, accent: Color, padding: PaddingValues, running: Boolean, done: Boolean, onStart: () -> Unit, onHelp: () -> Unit) {
    PageColumn(padding) {
        Header("Otimização", "Diagnóstico seguro do sistema", accent, onHelp)
        PanelCard(accent) {
            Text(if (running) "ANALISANDO..." else if (done) "ANÁLISE CONCLUÍDA" else "PRONTO PARA ANALISAR", color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Verificamos indicadores reais sem apagar seus arquivos ou encerrar outros aplicativos.", color = Color.White, fontSize = 14.sp)
            if (running) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = accent)
                Text("Coletando dados do Android...", color = Muted, fontSize = 12.sp)
            }
            Button(onClick = onStart, enabled = !running, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                Text(if (done) "ANALISAR NOVAMENTE" else "INICIAR ANÁLISE", color = Navy, fontWeight = FontWeight.Bold)
            }
        }
        Text("RELATÓRIO DO DISPOSITIVO", color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        InfoRow("Memória disponível", bytes(s.ramAvailable))
        InfoRow("Memória total", bytes(s.ramTotal))
        InfoRow("Armazenamento livre", bytes(s.storageAvailable))
        InfoRow("Armazenamento total", bytes(s.storageTotal))
        InfoRow("Bateria", if (s.batteryPercent >= 0) "${s.batteryPercent}%" else "Não informado pelo sistema")
        InfoRow("Temperatura", s.batteryTemp?.let { "$it °C" } ?: "Não disponibilizada")
        if (done) {
            PanelCard(accent) {
                Text("RECOMENDAÇÕES", color = accent, fontWeight = FontWeight.Bold)
                Text(if (s.storageUsedPercent >= 90) "O armazenamento está bastante ocupado. Revise arquivos grandes e aplicativos que você não usa." else "O espaço de armazenamento não indica ocupação crítica neste momento.", color = Color.White)
                Text(if (s.ramAvailable < 512L * 1024 * 1024) "A memória disponível está baixa. Feche tarefas que você abriu e não está usando, se necessário." else "A memória disponível está dentro de uma faixa confortável para o momento da leitura.", color = Color.White)
                Text("Nenhuma limpeza automática foi executada.", color = Muted, fontSize = 11.sp)
            }
        }
        PanelCard(accent) {
            Text("O que o Android permite?", color = accent, fontWeight = FontWeight.Bold)
            Text("Aplicativos comuns não podem limpar a memória de outros apps, alterar parâmetros protegidos ou encerrar processos de terceiros livremente. O INJECT M limita-se a leituras autorizadas e recomendações.", color = Color.White, fontSize = 12.sp)
        }
    }
}

@Composable
private fun GameScreen(context: Context, accent: Color, padding: PaddingValues, search: String, onSearch: (String) -> Unit, onHelp: () -> Unit) {
    val apps = remember { launchableApps(context) }
    val filtered = apps.filter { it.label.contains(search, true) || it.packageName.contains(search, true) }
    PageColumn(padding) {
        Header("Game Boost", "Inicie seus aplicativos por aqui", accent, onHelp)
        OutlinedTextField(search, onSearch, modifier = Modifier.fillMaxWidth(), label = { Text("Buscar aplicativo") }, singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, focusedLabelColor = accent, cursorColor = accent, unfocusedTextColor = Color.White, focusedTextColor = Color.White))
        PanelCard(accent) {
            Text("${apps.size} aplicativos inicializáveis encontrados", color = Color.White, fontWeight = FontWeight.Bold)
            Text("A lista usa as atividades de inicialização que o Android disponibiliza para este app.", color = Muted, fontSize = 11.sp)
        }
        if (filtered.isEmpty()) Text("Nenhum aplicativo correspondente foi encontrado.", color = Muted)
        filtered.forEach { app ->
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).clickable {
                    val launch = context.packageManager.getLaunchIntentForPackage(app.packageName)
                    if (launch != null) context.startActivity(launch)
                }.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(app.label, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(if (app.isSystem) "Aplicativo do sistema" else "Aplicativo instalado", color = Muted, fontSize = 10.sp)
                }
                Icon(Icons.Default.Launch, null, tint = accent)
            }
        }
    }
}

@Composable
private fun ToolsScreen(context: Context, s: DeviceSnapshot, accent: Color, padding: PaddingValues, onHelp: (String) -> Unit, onRefresh: () -> Unit) {
    var selected by remember { mutableStateOf("Resumo") }
    val tools = listOf("Resumo", "Monitor de RAM", "Armazenamento", "Bateria", "Informações do dispositivo", "Gerenciador de aplicativos", "Diagnóstico do sistema")
    PageColumn(padding) {
        Header("Ferramentas", "Monitores e utilitários do aparelho", accent)
        tools.forEach { name ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (selected == name) Color(0xFF15304A) else Panel).clickable { selected = name }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(name, color = Color.White, modifier = Modifier.weight(1f), fontWeight = if (selected == name) FontWeight.Bold else FontWeight.Normal)
                Icon(Icons.Default.ChevronRight, null, tint = accent)
            }
        }
        PanelCard(accent) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(selected.uppercase(), color = accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 12.sp)
                IconButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null, tint = accent) }
                IconButton(onClick = { onHelp("Esta ferramenta exibe informações disponibilizadas pelas APIs públicas do Android. Alguns detalhes variam conforme fabricante e versão do sistema.") }) { Icon(Icons.Default.HelpOutline, null, tint = accent) }
            }
            when (selected) {
                "Resumo" -> {
                    InfoRow("RAM livre", bytes(s.ramAvailable)); InfoRow("Armazenamento livre", bytes(s.storageAvailable)); InfoRow("Bateria", if (s.batteryPercent >= 0) "${s.batteryPercent}%" else "Indisponível")
                }
                "Monitor de RAM" -> {
                    InfoRow("RAM total", bytes(s.ramTotal)); InfoRow("RAM disponível", bytes(s.ramAvailable)); InfoRow("RAM em uso (estimativa)", "${s.ramUsedPercent}%")
                }
                "Armazenamento" -> {
                    InfoRow("Total da partição de dados", bytes(s.storageTotal)); InfoRow("Disponível", bytes(s.storageAvailable)); InfoRow("Ocupado", "${s.storageUsedPercent}%")
                }
                "Bateria" -> {
                    InfoRow("Nível", if (s.batteryPercent >= 0) "${s.batteryPercent}%" else "Indisponível"); InfoRow("Temperatura", s.batteryTemp?.let { "$it °C" } ?: "Não fornecida"); InfoRow("Estado", if (s.batteryCharging) "Carregando ou completa" else "Não carregando")
                }
                "Informações do dispositivo" -> {
                    InfoRow("Fabricante", s.manufacturer); InfoRow("Modelo", s.model); InfoRow("Android", s.android); InfoRow("Arquitetura", System.getProperty("os.arch") ?: "Não informada")
                }
                "Gerenciador de aplicativos" -> {
                    val apps = remember { launchableApps(context) }
                    InfoRow("Aplicativos inicializáveis", apps.size.toString())
                    Text("Abra a aba Game Boost para pesquisar e iniciar aplicativos.", color = Muted, fontSize = 12.sp)
                }
                else -> {
                    InfoRow("Memória", if (s.ramAvailable > 0) "Leitura disponível" else "Não disponível")
                    InfoRow("Armazenamento", if (s.storageTotal > 0) "Leitura disponível" else "Não disponível")
                    InfoRow("Bateria", if (s.batteryPercent >= 0) "Leitura disponível" else "Não disponível")
                    Text("O diagnóstico não altera configurações do sistema.", color = Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 12.sp)
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun SettingsScreen(
    theme: String, onTheme: (String) -> Unit, glow: Float, onGlow: (Float) -> Unit,
    animations: Boolean, onAnimations: (Boolean) -> Unit, compact: Boolean, onCompact: (Boolean) -> Unit,
    onTutorial: () -> Unit, onContinue: () -> Unit, onReset: () -> Unit, accent: Color, padding: PaddingValues
) {
    PageColumn(padding) {
        Header("Configurações", "Personalize sua experiência", accent)
        PanelCard(accent) {
            Text("TEMAS", color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            themeNames.forEach { name ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onTheme(name) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = theme == name, onClick = { onTheme(name) }, colors = RadioButtonDefaults.colors(selectedColor = accent))
                    Text(name, color = Color.White, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }
        PanelCard(accent) {
            Text("EFEITOS VISUAIS", color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("Intensidade do brilho azul: ${(glow * 100).roundToInt()}%", color = Color.White)
            Slider(value = glow, onValueChange = onGlow, colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Animações", color = Color.White, modifier = Modifier.weight(1f))
                Switch(animations, onAnimations, colors = SwitchDefaults.colors(checkedThumbColor = accent))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Cartões compactos", color = Color.White, modifier = Modifier.weight(1f))
                Switch(compact, onCompact, colors = SwitchDefaults.colors(checkedThumbColor = accent))
            }
            Text("Prévia do tema", color = Muted, fontSize = 11.sp)
            Box(Modifier.fillMaxWidth().height(62.dp).clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(accent.copy(alpha = glow), Color(0xFF0A1727)))), contentAlignment = Alignment.Center) {
                Text("INJECT M  •  $theme", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        PanelCard(accent) {
            Text("GUIA DO INJECT M", color = accent, fontWeight = FontWeight.Bold)
            Text("Aprenda a utilizar todas as áreas do aplicativo. O progresso é salvo localmente.", color = Muted, fontSize = 12.sp)
            Button(onClick = onTutorial, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("RECOMEÇAR TUTORIAL", color = Navy, fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = onContinue, modifier = Modifier.fillMaxWidth()) { Text("CONTINUAR DE ONDE PAREI") }
        }
        PanelCard(accent) {
            Text("SOBRE", color = accent, fontWeight = FontWeight.Bold)
            InfoRow("Aplicativo", "INJECT M")
            InfoRow("Versão", "1.0.0")
            InfoRow("Desenvolvedor", "LEONARDO")
            Text("DEVELOPED BY LEONARDO", color = Muted, fontSize = 10.sp)
            OutlinedButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) { Text("RESTAURAR CONFIGURAÇÕES") }
        }
    }
}

@Composable
private fun TutorialScreen(step: Int, onStep: (Int) -> Unit, onFinish: () -> Unit, onSkip: () -> Unit, accent: Color) {
    val current = step.coerceIn(0, 6)
    val progress by animateFloatAsState((current + 1) / 7f, label = "tutorial-progress")
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Column {
            Text("INJECT M", color = accent, fontSize = 30.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("DEVELOPED BY LEONARDO", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(28.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("GUIA DE INTRODUÇÃO", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("${current + 1} / 7", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(CircleShape), color = accent, trackColor = Panel)
            Spacer(Modifier.height(26.dp))
            AnimatedContent(targetState = current, label = "tutorial-step") { index ->
                Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text(tutorialTitles[index], color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Box(Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF14385A), Color(0xFF091323)))), contentAlignment = Alignment.Center) {
                        Text(if (index == 6) "INJECT M" else "0${index + 1}", color = accent, fontSize = 56.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                    }
                    Text(tutorialBodies[index], color = Color(0xFFD5E4F2), fontSize = 15.sp, lineHeight = 23.sp)
                    if (index == 0) {
                        Text("Dados reais • Diagnóstico seguro • Personalização offline", color = accent, fontSize = 11.sp)
                    }
                }
            }
        }
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (current == 6) {
                Button(onClick = onFinish, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                    Text("FINALIZAR TUTORIAL", color = Navy, fontWeight = FontWeight.ExtraBold)
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { onStep((current - 1).coerceAtLeast(0)) }, enabled = current > 0, modifier = Modifier.weight(1f)) { Text("VOLTAR") }
                    Button(onClick = { onStep(current + 1) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("AVANÇAR", color = Navy, fontWeight = FontWeight.Bold) }
                }
            }
            TextButton(onClick = onSkip, modifier = Modifier.fillMaxWidth()) { Text("PULAR TUTORIAL", color = Muted) }
        }
    }
}
