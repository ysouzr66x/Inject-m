# INJECT M — DEVELOPED BY LEONARDO

Projeto Android nativo em Kotlin + Jetpack Compose.

## O que está implementado

- Leitura de RAM disponível/total via `ActivityManager.MemoryInfo`.
- Leitura do espaço da partição de dados via `StatFs`.
- Nível, estado e temperatura da bateria quando o Android fornece esses dados.
- Fabricante, modelo e versão Android via `Build`.
- Lista de apps com atividade de inicialização visível ao aplicativo e abertura via `getLaunchIntentForPackage`.
- Diagnóstico informativo sem apagar arquivos ou encerrar processos de terceiros.
- Cinco áreas principais: Início, Otimização, Game Boost, Ferramentas e Configurações.
- Cinco temas e preferências persistidas em SharedPreferences.
- Tutorial offline de sete etapas, com progresso salvo e opção de recomeçar/continuar.
- Ajuda contextual nas áreas principais.

## Limitações reais do Android

INJECT M não usa ROOT e não tenta contornar as proteções do sistema. Aplicativos comuns não podem:
- encerrar livremente processos de outros aplicativos;
- limpar caches privados de terceiros;
- prometer aumento de FPS;
- alterar configurações protegidas sem APIs/permissões especiais.

A lista de aplicativos é limitada à visibilidade permitida pelo Android e às atividades que declaram uma intent de inicialização. Alguns fabricantes podem restringir ou omitir informações, especialmente sensores de temperatura.

O valor de RAM é a memória disponível informada pelo sistema, não uma medição de memória livre garantida para um jogo. O armazenamento representa a partição de dados acessível pela consulta `StatFs`.

## Requisitos para compilar

- Android Studio recente (recomendado Iguana ou superior).
- JDK 17.
- Android SDK Platform 35 e Build Tools compatíveis.
- Conexão com internet na primeira compilação para baixar dependências Gradle.

## Como compilar

1. Extraia o ZIP.
2. Abra a pasta `INJECT-M-Projeto` no Android Studio.
3. Aguarde a sincronização Gradle.
4. Se necessário, instale o Android SDK 35 pelo SDK Manager.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Instalação pelo ZArchiver

Se o APK tiver sido compilado:
1. Extraia `INJECT-M-Projeto.zip` no ZArchiver.
2. Entre na pasta `INJECT-M-Projeto/app/build/outputs/apk/debug/`.
3. Toque em `app-debug.apk`.
4. Autorize a instalação dessa origem, caso o Android solicite.
5. Confirme a instalação.

O ZIP é um arquivo de projeto, não é instalável diretamente como APK.

## Compatibilidade

`minSdk = 26` (Android 8.0). O projeto usa APIs públicas do Android. `targetSdk = 35`.
